﻿#https://msdn.microsoft.com/en-us/powershell/dsc/authoringresourceclass

enum Ensure
{
    Enabled
    Disabled
}

<#
   This resource manages the file in a specific path.
   [DscResource()] indicates the class is a DSC resource
#>

[DscResource()]
class HyperVThreadingCheck
{
    <#
       This property is the fully qualified path to the file that is
       expected to be present or absent.

       The [DscProperty(Key)] attribute indicates the property is a
       key and its value uniquely identifies a resource instance.
       Defining this attribute also means the property is required
       and DSC will ensure a value is set before calling the resource.

       A DSC resource must define at least one key property.
    #>
    [DscProperty(Key)]
    [Ensure]$Ensure

    <#
       This property reports the file's create timestamp.

       [DscProperty(NotConfigurable)] attribute indicates the property is
       not configurable in DSC configuration.  Properties marked this way
       are populated by the Get() method to report additional details
       about the resource when it is present.

    #>
    [DscProperty(NotConfigurable)]
    [Nullable[datetime]] $CreationTime

    <#
        This method is equivalent of the Set-TargetResource script function.
        It sets the resource to the desired state.
    #>
    [void] Set()
    {

        # We're not doing anything here.  Do you expect us to enable hyperthreading?  WTF.

    }

    <#
        This method is equivalent of the Test-TargetResource script function.
        It should return True or False, showing whether the resource
        is in a desired state.
    #>
    [bool] Test()
    {

        $proc = Get-CimInstance win32_processor
        $comp = Get-CimInstance win32_computersystem

        $procs = $proc.NumberOfLogicalProcessors | Measure-Object -Sum | Select-Object Sum
        $cores = $proc.NumberofCores | Measure-Object -Sum | Select-Object Sum

        if($comp.Manufacturer -eq 'Microsoft')
        {
            return $true
        }

        if($procs.Sum -gt $cores.Sum)
        {
            if ($this.Ensure -eq [Ensure]::Enabled)
            {
                Write-Verbose 'Hyperthreading is enabled.  This is expected.'
                return $true
            }
            else 
            {
                Write-Verbose 'Hyperthreading is enabled.  This is bad.'
                return $false
            }
        }
        else
        {
            if ($this.Ensure -eq [Ensure]::Disabled)
            {
                Write-Verbose 'Hyperthreading is disabled.  This is expected.'
                return $true
            }
            else 
            {
                Write-Verbose 'Hyperthreading is disabled.  This is bad.'
                return $false
            }
        }

    }

    <#
        This method is equivalent of the Get-TargetResource script function.
        The implementation should use the keys to find appropriate resources.
        This method returns an instance of this class with the updated key
         properties.
    #>
    [HyperVThreadingCheck] Get()
    {

        $proc = Get-CimInstance win32_processor
        $comp = Get-CimInstance win32_computersystem

        $procs = $proc.NumberOfLogicalProcessors | Measure-Object -Sum | Select-Object Sum
        $cores = $proc.NumberofCores | Measure-Object -Sum | Select-Object Sum


        if($comp.Manufacturer -eq 'Microsoft')
        {
            return $true
        }

        if($procs.Sum -gt $cores.Sum)
        {
            if ($this.Ensure -eq [Ensure]::Enabled)
            {
                Write-Verbose 'Hyperthreading is enabled.  This is expected.'
                return $this
            }
            else 
            {
                Write-Verbose 'Hyperthreading is enabled.  This is bad.'
                return $this
            }
        }
        else
        {
            if ($this.Ensure -eq [Ensure]::Disabled)
            {
                Write-Verbose 'Hyperthreading is disabled.  This is expected.'
                return $this
            }
            else 
            {
                Write-Verbose 'Hyperthreading is disabled.  This is bad.'
                return $this
            }
        }

    }

} # This module defines a class for a DSC "FileResource" provider.
