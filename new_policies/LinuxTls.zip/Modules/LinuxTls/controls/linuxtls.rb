connectionScript='
#!/bin/bash

##
# Generic TLS 1.2+ check
test="PASS"
SERVICES="httpd apache apache2 nginx mongod pgsql mysqld mongod pgsql mysqld"
for SERVICE in $SERVICES
do
    PORTS=$(sudo lsof -p $(pidof -s $SERVICE) 2>/dev/null | grep LISTEN |  perl -0pe "s/.*TCP\s+[^:]+:(.*)\(LISTEN\)/\1/s")

    for PORT in $PORTS
    do
        # Initialize volues on success
        TLSv10=1
        TLSv11=1
        TLSv12=1

        TLSv10=$(echo close | openssl s_client -connect localhost:$PORT -tls1 2>&1 | perl -0 -pi -e "s/.*(New\,\s+\S+\s+Cipher is [A-Z0-9-]+)\n.*(Protocol\s+\:\s+TLSv1\s).*/\1 \2/sg" | wc -l)
        TLSv11=$(echo close | openssl s_client -connect localhost:$PORT -tls1_1 2>&1 | perl -0 -pi -e "s/.*(New\,\s+\S+\s+Cipher is [A-Z0-9-]+)\n.*(Protocol\s+\:\s+TLSv1.1\s).*/\1 \2/sg" | wc -l)
        TLSv12=$(echo close | openssl s_client -connect localhost:$PORT -tls1_2 2>&1 | perl -0 -pi -e "s/.*(New\,\s+\S+\s+Cipher is [A-Z0-9-]+)\n.*(Protocol\s+\:\s+TLSv1.2\s).*/\1 \2/sg" | wc -l)

        # add logic to validate the connections. if one fails exit the loop or stop counting
        if [ $TLSv10 -eq 1 ]; then # this means the protocol is supported.
            test="FAIL"
            break
        fi
        
        if [ $TLSv11 -eq 1 ]; then # this means the protocol is supported.
            test="FAIL"
            break
        fi
        
        if [ $TLSv12 -gt 1 ]; then # this means the protocol is supported.
            test="FAIL"
            break
        fi

    done

done


if [ $test = "PASS" ]; then
    echo "Compliant"
else
    echo "Not Compliant"
fi
'

describe command(connectionScript) do
    its('stdout') { should eq "Compliant\n" }
    its('exit_status') { should eq 0 }
end
