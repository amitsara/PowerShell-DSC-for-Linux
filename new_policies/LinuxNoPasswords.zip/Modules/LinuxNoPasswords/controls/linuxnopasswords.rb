scriptNoPassword = '
#!/bin/bash
#

if [ $(cat /etc/shadow | grep -Ev \(\[\*\]\|\[\!\]\|\[\*\]NP\[\*\]\) | wc -l) -eq 0  ]
then
	echo "Compliant"
else 
	echo "NOT Compliant\n"
fi
'

describe command (scriptNoPassword) do
	its('stdout') { should eq "Compliant\n" }
	its('exit_status') { should cmp 0 }
end