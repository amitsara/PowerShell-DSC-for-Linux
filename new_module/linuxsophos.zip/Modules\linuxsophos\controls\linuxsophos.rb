InstallScriptCheck= '
#!/bin/bash

##
# Sophos install check.

if [ -f /opt/sophos-av/install.sh ]
then
    echo "Compliant"
else
    echo "Not Compliant"
fi
'

RunningScriptCheck = '
#!/bin/bash

##
# Sophos running check.

if [ $(ps -ef | grep sophosmgmtd | grep -v "grep" | wc -l) -gt 0 ]
then
    echo "Sophos is Running"
else
    echo "Sophos is NOT Running"
fi
'

describe command(InstallScriptCheck) do
    its('stdout') { should eq "Compliant\n" }
    its('exit_status') { should eq 0 }
end

describe command(RunningScriptCheck) do
    its('stdout') { should eq "Sophos is Running\n"}
    its('exit_status') { should cmp 0 }
end