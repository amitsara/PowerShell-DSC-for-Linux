confScript = '
#!/bin/bash
#

##
# Check auditd config compliance.

echo "log_file = /var/log/audit/audit.log
log_format = RAW
log_group = root
priority_boost = 4
flush = INCREMENTAL
freq = 20
num_logs = 5
disp_qos = lossy
dispatcher = /sbin/audispd
name_format = NONE
max_log_file = 6 
max_log_file_action = ROTATE
space_left = 75
space_left_action = SYSLOG
action_mail_acct = root
admin_space_left = 50
admin_space_left_action = SUSPEND
disk_full_action = SUSPEND
disk_error_action = SUSPEND
tcp_listen_queue = 5
tcp_max_per_addr = 1
tcp_client_max_idle = 0
enable_krb5 = no
krb5_principal = auditd" > /tmp/auditd.conf.cmp

if [ $(diff --changed-group-format=\'%<\' --unchanged-group-format=\'\' /tmp/auditd.conf.cmp /etc/audit/auditd.conf | wc -l) -gt 0 ]
    then
        echo "auditd conf NOT Compliant"
    else
        echo "auditd conf IS Compliant"
    fi
    
    rm /tmp/auditd.conf.cmp
'
rulesScript = '
#!/bin/bash
#

##
# Check auditd rules compliance.

echo "# Copied from /usr/share/doc/audit-2.2/stig.rules and /root/backup/8-2-2016-audit.rules
# See those files for comments
-D
-b 16384
-f 2

## Things that could affect time
-a always,exit -F arch=b32 -S adjtimex -S settimeofday -S stime -k time-change
-a always,exit -F arch=b64 -S adjtimex -S settimeofday -k time-change
-a always,exit -F arch=b32 -S clock_settime -F a0=0 -k time-change
-a always,exit -F arch=b64 -S clock_settime -F a0=0 -k time-change
-w /etc/localtime -p wa -k time-change

## Things that affect identity
-w /etc/group -p wa -k identity
-w /etc/passwd -p wa -k identity
-w /etc/gshadow -p wa -k identity
-w /etc/shadow -p wa -k identity
-w /etc/security/opasswd -p wa -k identity
-w /etc/security -p wa -k identity

## Watch the certs and openssl libs
-w /etc/pki/tls/certs/ -p wa -k certificates
-w /usr/include/openssl/ -p wa -k openssl
-w /usr/lib64/ -p wa -k libraries

## Watch for changes to pam configs
-w /etc/pam.d/ -p wa -k pam_configs

## Things that could affect system locale
-a always,exit -F arch=b32 -S sethostname -S setdomainname -k system-locale
-a always,exit -F arch=b64 -S sethostname -S setdomainname -k system-locale
-w /etc/issue -p wa -k system-locale
-w /etc/issue.net -p wa -k system-locale
-w /etc/hosts -p wa -k system-locale
-w /etc/sysconfig/network -p wa -k system-locale

## Things that could affect MAC policy
-w /etc/selinux/ -p wa -k MAC-policy

## - Logon (unsuccessful and successful) and logout (successful)
## Might also want to watch these files if needing extra information
-w /var/log/tallylog -p wa -k logins
-w /var/run/faillock/ -p wa -k logins
-w /var/log/lastlog -p wa -k logins

##- Process and session initiation (unsuccessful and successful)
-w /var/run/utmp -p wa -k session
-w /var/log/btmp -p wa -k session
-w /var/log/wtmp -p wa -k session

##- Discretionary access control permission modification (unsuccessful
## and successful use of chown/chmod)
-a always,exit -F arch=b32 -S chmod -S fchmod -S fchmodat -F auid>=500 -F auid!=4294967295 -k perm_mod
-a always,exit -F arch=b64 -S chmod -S fchmod -S fchmodat -F auid>=500 -F auid!=4294967295 -k perm_mod
-a always,exit -F arch=b32 -S chown -S fchown -S fchownat -S lchown -F auid>=500 -F auid!=4294967295 -k perm_mod
-a always,exit -F arch=b64 -S chown -S fchown -S fchownat -S lchown -F auid>=500 -F auid!=4294967295 -k perm_mod
-a always,exit -F arch=b32 -S setxattr -S lsetxattr -S fsetxattr -S removexattr -S lremovexattr -S fremovexattr -F auid>=500 -F auid!=4294967295 -k perm_mod
-a always,exit -F arch=b64 -S setxattr -S lsetxattr -S fsetxattr -S removexattr -S lremovexattr -S fremovexattr -F auid>=500 -F auid!=4294967295 -k perm_mod

##- Unauthorized access attempts to files (unsuccessful) 
-a always,exit -F arch=b32 -S creat -S open -S openat -S open_by_handle_at -S truncate -F exit=-EACCES -F auid>=500 -F auid!=4294967295 -k access
-a always,exit -F arch=b32 -S creat -S open -S openat -S open_by_handle_at -S truncate -F exit=-EPERM -F auid>=500 -F auid!=4294967295 -k access
-a always,exit -F arch=b64 -S creat -S open -S openat -S open_by_handle_at -S truncate -F exit=-EACCES -F auid>=500 -F auid!=4294967295 -k access
-a always,exit -F arch=b64 -S creat -S open -S openat -S open_by_handle_at -S truncate -F exit=-EPERM -F auid>=500 -F auid!=4294967295 -k access

##- Use of privileged commands (unsuccessful and successful)
-a always,exit -F path=/bin/ping6 -F perm=x -F auid>=500 -F auid!=4294967295 -k privileged
-a always,exit -F path=/bin/umount -F perm=x -F auid>=500 -F auid!=4294967295 -k privileged
-a always,exit -F path=/bin/mount -F perm=x -F auid>=500 -F auid!=4294967295 -k privileged
-a always,exit -F path=/bin/su -F perm=x -F auid>=500 -F auid!=4294967295 -k privileged
-a always,exit -F path=/bin/ping -F perm=x -F auid>=500 -F auid!=4294967295 -k privileged

## Watch for anyone shutting down or rebooting the server
-a always,exit -F path=/sbin/reboot -F perm=x -k shutdown
-a always,exit -F path=/sbin/shutdown -F perm=x -k shutdown

##- Files and programs deleted by the user (successful and unsuccessful)
-a always,exit -F arch=b32 -S unlink -S unlinkat -S rename -S renameat -F auid>=500 -F auid!=4294967295 -k delete
-a always,exit -F arch=b64 -S unlink -S unlinkat -S rename -S renameat -F auid>=500 -F auid!=4294967295 -k delete

-w /etc/sudoers -p wa -k actions

##  module insertion(also watch for process blacklist changes)
-w /sbin/insmod -p x -k modules
-w /sbin/rmmod -p x -k modules
-w /sbin/modprobe -p x -k modules
-w /lib/modprobe.d -p x -k modules
-w /etc/modprobe.d -p x -k modules
-w /run/modprobe.d -p x -k modules

-a always,exit -F arch=b32 -S init_module -S delete_module -k modules
-a always,exit -F arch=b64 -S init_module -S delete_module -k modules


# Watch (startup) folders for possible persistence
-a always,exit -F dir=/etc/conf.d -F perm=wa -F key=startup
-a always,exit -F dir=/etc/init.d -F perm=wa -F key=startup
-a always,exit -F path=/etc/rc.conf -F perm=wa -F key=startup

## Watch write to the system startup scripts
-w /etc/inittab -p wa -k init
-w /etc/init.d/ -p wa -k init
-w /etc/init/ -p wa -k init

#Watch for changes to the Kernel Parameters
-a always,exit -F arch=b64 -F path=/etc/sysctl.conf -F perm=wa -F key=sysctl

## Protect the audit trail
-w /var/log/audit/ -k LOG_audit
-w /etc/audit/ -p wa -k CFG_audit
-w /etc/sysconfig/auditd  -p wa -k CFG_auditd.conf
-w /etc/libaudit.conf -p wa -k CFG_libaudit.conf
-w /etc/audisp/ -p wa -k CFG_audisp
-a always,exit -F arch=b64 -S chmod -S fchmod -S fchmodat 
-a always,exit -F arch=b64 -S chown -S fchown -S fchownat -S lchown

# watch package installation via APT/dpkg
-w /usr/bin/dpkg -p x -k moduleinstallation
-w /usr/bin/apt-add-repository -p x -k moduleinstallation
-w /usr/bin/apt-get -p x -k moduleinstallation
-w /usr/bin/aptitude -p x -k moduleinstallation

## Make the configuration immutable - reboot is required to change audit rules
# -e 2" > /tmp/audit.rules.cmp

if [ $(diff --changed-group-format=\'%<\' --unchanged-group-format=\'\' /tmp/audit.rules.cmp /etc/audit/audit.rules | wc -l) -gt 0 ]
then
    echo "auditd rules NOT Compliant"
else
    echo "auditd rules IS Compliant"
fi

rm /tmp/audit.rules.cmp
'

describe command(rulesScript) do
    its('stdout') { should eq "auditd rules IS Compliant\n"}
end

describe command(confScript) do
    its('stdout') { should eq "auditd conf IS Compliant\n"}
end
